/**
  **************************************************************************
  * @file     readme.txt 
  * @version  v2.0.0
  * @date     2020-11-02
  * @brief    readme
  **************************************************************************
  */

  this demo is based on the at-start board and AT32-Comm-EV, in this demo, 
  shows how to use usart to achieve modbus communication(rs485/rs232) and 
  port modbus protocol stack.

  set-up
  - usart tx     --->   pa2
  - usart rx     --->   pa3
  - usart de     --->   pa1
  